from pathlib import Path
import hashlib,json,sys
P=Path(__file__).resolve().parent
for n,h in json.loads((P/'SHA256SUMS.json').read_text()).items():
 assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
print('All archive member hashes match')
if '--hashes-only' not in sys.argv:
 sys.path.insert(0,str(P))
 from materialmind.server import ROOT,load_dataset
 from materialmind.sessions import SessionEngine
 r=json.loads((P/'session.json').read_text()); e=SessionEngine(ROOT,load_dataset()); result=e.export(e.restore(r))
 assert all(result[k]==r[k] for k in r if k!='exported_at')
 print('Native restore exact except export timestamp; one reveal, one geometry-only import')
