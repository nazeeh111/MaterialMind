# MaterialMind: one archived reference and one edited cell

This archive contains the exact current-main Python/WebGL source, public WBM-derived data, retained research outputs and native schema-3 example. It is not a new DFT calculation, synthesis, model-training study or benchmark rerun. Code MIT; data CC BY 4.0. See LICENSE, DATA_LICENSE.md, CITATION.cff and materialmind/web/vendor/THREE-LICENSE.txt. The selected case does not overturn the negative aggregate policy comparison.

Contents: materialmind/ (runtime, public data, retained study), pyproject.toml, requirements-worked.lock, session.json (one reveal plus volume-edited geometry), ui-session.json (actual workbench export), selected.cif, edited.cif, before.json, reveal.json, after.json, edited-import.json, figure-data.json, figure.py, check.py and SHA256SUMS.json.

Inspect: read reveal.json for selection-time predictions and the archived label; figure-data.json holds all initial lattice/sites and exact acquisition values. Import edited.cif into the workbench: geometry is validated, prediction is withheld. No new energy or label exists for that edit. Session labels/predictions are readable annotations, not trusted restore inputs.

Verify stored bytes without installing anything: python3 check.py --hashes-only

For native reconstruction, use the recorded CPython3.12.13/macOSARM64 environment. Create a separate venv, install exact requirements-worked.lock, then run `pip install --no-deps .`. The requirements are a tested environment snapshot, not the repository research-release lock. Run OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python check.py . It reconstructs session.json using the included source/data and compares all exported fields except the new export timestamp. A different source/data/package/Python/platform contract is deliberately refused. A different environment should produce and restore its own fresh export. Do not bypass the guard.

Open the app: materialmind serve --port 8767 ; visit http://127.0.0.1:8767 . Choose Restore record, load session.json, confirm replacement. The source uses memory-only local sessions: export before stopping. No uploaded model or code is executed by restore.

Source/provenance: https://github.com/nazeeh111/MaterialMind/tree/2340213234ab6ddf8e0f5f86361d71ac432ff59c ; scientific report https://github.com/nazeeh111/MaterialMind/blob/2340213234ab6ddf8e0f5f86361d71ac432ff59c/docs/REPORT.md ; upstream identifiers and transformations are local materialmind/data/provenance.json and DATA_LICENSE.md. No figure manifest is included because the repository manifest hashes this ZIP.
